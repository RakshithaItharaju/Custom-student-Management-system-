# Custom Student Management System (PHP + MySQL)

## 📌 Introduction
The **Custom Student Management System** is a web-based application built using **PHP** and **MySQL** to manage student records efficiently.  
It allows administrators to add, update, delete, and view student information, reducing paperwork and ensuring data accuracy.

This project was developed as part of academic work to demonstrate backend development, database management, and CRUD functionality.

---

## 🎯 Project Objectives
- Develop a centralized system for student data management.
- Implement CRUD operations for efficient record handling.
- Provide a simple and intuitive user interface.
- Enable quick search and filtering of records.
- Maintain data consistency in the database.

---

## 👩‍💻 Author
**Itharaju Rakshitha**  
B.Tech Computer Science and Engineering  
Sreenidhi Institute of Science and Technology
