<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "student_db";
$conn = mysqli_connect($host, $user, $password, $db);
?>
